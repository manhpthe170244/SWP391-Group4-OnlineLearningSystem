SET IDENTITY_INSERT Post_Category ON
INSERT INTO Post_Category(blog_id, blog_name, blog_title, updated_date) VALUES (1,N'Programming Basics',N'Introduction to Python Programming','2023-05-15 00:00:00'),
	(2,N'Web Development',N'Building Responsive Websites with HTML and CSS','2023-04-28 00:00:00'),
	(3,N'Data Science',N'Exploratory Data Analysis using Python','2023-05-10 00:00:00'),
	(4,N'Business and Finance',N'Financial Planning for Small Businesses','2023-05-20 00:00:00'),
	(5,N'Graphic Design',N'Introduction to Adobe Photoshop for Beginners','2023-05-03 00:00:00'),
	(6,N'Marketing',N'Social Media Marketing Strategies for E-commerce','2023-05-12 00:00:00'),
	(7,N'Personal Development',N'Mastering Time Management Skills','2023-05-25 00:00:00'),
	(8,N'Language Learning',N'Conversational Spanish for Travelers','2023-05-18 00:00:00'),
	(9,N'Health and Fitness',N'Effective Workout Routines for Weight Loss','2023-05-07 00:00:00'),
	(10,N' Photography',N'Introduction to Landscape Photography Techniques','2023-05-22 00:00:00');

